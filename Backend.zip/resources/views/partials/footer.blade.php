<footer class="footer">
    <div class="container-fluid d-flex justify-content-between">
        <nav class="pull-left">

        </nav>
        <div class="copyright">
            {{date('Y')}}, made with <i class="fa fa-heart heart text-danger"></i> by
            <a href="">DIPLOY</a>
        </div>
        <div>

        </div>
    </div>
</footer>

