<!DOCTYPE html>
<html>
<head>
    <title>Your OTP</title>
</head>
<body>
    <h1>Hello there,</h1>
    <p>Your one-time password (OTP) for login is: <strong>{{ $otp }}</strong></p>
    <p>This code is valid for 5 minutes. Do not share it with anyone.</p>
</body>
</html>
